package com.ankesh.model;

public class Symptoms {

}
