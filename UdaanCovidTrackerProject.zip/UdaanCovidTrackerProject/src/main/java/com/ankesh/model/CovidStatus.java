package com.ankesh.model;

public enum CovidStatus {
	NEGATIVE, POSITIVE
}
