package com.ankesh.model;

public enum ZoneStatus {
	GREEN,ORANGE,RED
}
