package com.ankesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdaanProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(UdaanProjectApplication.class, args);
	}

}
